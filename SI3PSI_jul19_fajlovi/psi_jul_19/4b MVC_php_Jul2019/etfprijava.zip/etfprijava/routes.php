<?php
//funkcija call za ucitavanje odredjenog kontrolera 
//i akcije tog kontrolera odnosno neke veb strane
function call($controller, $akcija) {
    require_once('controllers/' . $controller . '_controller.php');

    switch ($controller) {
        case 'gost':
            $controller = new Gost();
            break;
        case 'nastavnik':
            $controller = new Nastavnik();
            break;
        case 'student':
            $controller = new Student();
            break;
    }
    $controller->$akcija();
}

//niz sa kontrolerima i svim akcijama tih kontrolera
$controllers = array('gost' => ['index', 'login','ulogujse'],
                    'nastavnik' => ['index','logout','zatvori_prijavu'],
                    'student' => ['index','logout','prijava_predmet','prijava_tim']);

if (array_key_exists($controller, $controllers)) {
    if (in_array($akcija, $controllers[$controller])) {
        call($controller, $akcija);
    } else {
        call('gost', 'greska');
    }
} else {
    call('gost', 'greska');
}
?>