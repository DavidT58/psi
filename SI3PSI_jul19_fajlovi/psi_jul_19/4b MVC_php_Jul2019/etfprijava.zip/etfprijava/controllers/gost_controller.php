<?php
require_once('models/ModelKorisnik.php');
class Gost{
    
    public function __construct() {       
        //provera da li je korisnik mozda vec ulogovan
        session_start();
        if (isset($_SESSION['nastavnik'])) {
            header("Location: ?controller=nastavnik&akcija=index");   
        }
        if (isset($_SESSION['student'])) {
            header("Location: ?controller=student&akcija=index");   
        }
    }
    
    public function index(){   
        require_once("views/login.php");
    }
          
    //metoda koja ucitava formu za  logovanje
    public function login($username=NULL, $poruka=NULL,$porukausername=NULL,$porukapassword=NULL)
    {
        require_once("views/login.php");
    }
    
    //metoda koja se poziva klikom na submit forme za logovanje
    public function ulogujse(){
        if ($_POST['username'] == "") {
            $porukausername = "Polje Username je ostalo prazno.";
        }else
            $porukausername=NULL;
        if ($_POST['password'] == "") {
            $porukapassword = "Polje Password je ostalo prazno.";
        } else {
            $porukapassword=NULL;
        }
        if($_POST['username']!="" && $_POST['password']!=""){
            $korisnik=ModelKorisnik::dohvatiKorisnika($_POST['username']);
            if ($korisnik==NULL) {
                $this->login($_POST['username'],"Neispravnan username!");
            } else if (!$korisnik->ispravanPassword($_POST['password'])) {
                $this->login($_POST['username'],"Neispravan password!");
            } else if($korisnik->jeNastavnik()){
                $_SESSION['nastavnik']= $korisnik;
                header("Location: ?controller=nastavnik&akcija=index");
            }
            else {
                $_SESSION['student']= $korisnik;
                header("Location: ?controller=student&akcija=index");
            }
        } else {
            $this->login($_POST['username'], NULL,$porukausername,$porukapassword);
        }
    }
    
    public function greska(){
        require_once 'views/greska.php';
    }

}
