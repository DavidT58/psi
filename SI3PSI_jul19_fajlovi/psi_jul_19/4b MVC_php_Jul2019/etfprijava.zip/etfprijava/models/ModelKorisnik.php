<?php
/**
 * Description of ModelKorisnik
 *
 * @author Korisnik
 */
class ModelKorisnik {
    private $username;
    private $password;


    public function __construct($username, $password) {
        $this->password = $password;
        $this->username = $username;
    }
    
    public function __get($imeAtributa) {
        return $this->$imeAtributa;
    }
    
    public static function dohvatiKorisnika($username){
        $konekcija = DB::getInstanca();
        $rezultat = $konekcija->query("SELECT * FROM korisnik WHERE username='$username'");     
        $korisnik = $rezultat->fetch();
        if ($korisnik!=NULL) {
            return new ModelKorisnik($korisnik['username'], $korisnik['password']);
        } else {
            return FALSE;
        }
    }
    
    public function ispravanPassword($password){
        if ($this->password == $password) {
            return TRUE;
        } else {
            return FALSE;
        }
    }   
    
    public function jeNastavnik(){
        $konekcija = DB::getInstanca();
        $rezultat = $konekcija->query("SELECT * FROM Nastavnik WHERE idNastavnik='".$this->username."'");  
        $korisnik = $rezultat->fetch();
        if ($korisnik!=NULL) {
            return TRUE;
        } else {
            return FALSE;
        }
    }
}